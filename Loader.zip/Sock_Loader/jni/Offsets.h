#ifndef OFFSETS_H
#define OFFSETS_H

// Offset Finder Tool By Dalton
//Dalton - @D1_VIP
namespace Offsets {

	//Class: Actor
    uintptr_t ReplicatedMovement = 0xb0; //RepMovement ReplicatedMovement;
	uintptr_t Role = 0x150; //byte Role;
	uintptr_t Children = 0x1a0; //Actor*[] Children;
	uintptr_t RootComponent = 0x1b0; //SceneComponent* RootComponent;
	uintptr_t DrawShootLineTime = 0x13c; //RepAttachment AttachmentReplication + FName AttachSocket + 0x4;
	
	//Class: SceneComponent
	uintptr_t FixAttachInfoList = 0x1b0; //FTransform ComponentToWorld;
	uintptr_t ParachuteEquipItems = 0x1c0; //FTransform ComponentToWorld + 0x10;

    uintptr_t ComponentVelocity = 0x260; //Vector ComponentVelocity;

	//Class: Pawn
    uintptr_t Controller = 0x460; //Controller* Controller;

	//Class: Controller
	uintptr_t ControlRotation = 0x458; //Rotator ControlRotation;

	//Class: Character
	uintptr_t Mesh = 0x490; //SkeletalMeshComponent* Mesh;

    //Class: SkinnedMeshComponent // 820
    uintptr_t MinLOD = 0x860; //FTransform[] ComponentSpaceTransforms;

    //Class: MovementComponent
    uintptr_t Velocity = 0x12c; //Vector Velocity;

    //Class: CharacterMovementComponent
    uintptr_t MaxWalkSpeed = 0x1f4; //float MaxWalkSpeed;
	uintptr_t MaxWalkSpeedCrouched = 0x1f8; //float MaxWalkSpeedCrouched;

	//Class: PlayerController
	uintptr_t PlayerCameraManager = 0x4c0; //PlayerCameraManager* PlayerCameraManager;

	//Class: PlayerCameraManager
	uintptr_t CameraCache2 = 0x4a0 + 0x10; //CameraCacheEntry CameraCache;
	uintptr_t CameraCache = 0x1020 + 0x10; //TViewTarget ViewTarget;

	//Class: CameraComponent
	uintptr_t FieldOfView = 0x33c; //float FieldOfView;

	//Class: UAECharacter
    uintptr_t PlayerName = 0x8e0; //FString PlayerName;
	uintptr_t Nation = 0x8f0; //FString Nation;
	uintptr_t PlayerUID = 0x908; //FString PlayerUID;
	uintptr_t TeamID = 0x928; //int TeamID;
	uintptr_t bIsAI = 0x9d9; //bool bEnsure;

	//Class: STExtraCharacter
	uintptr_t Health = 0xda0; //float Health;
	uintptr_t bDead = 0xdbc; //bool bDead;
	uintptr_t bIsGunADS = 0x1031; //bool bIsGunADS;
    uintptr_t CurrentVehicle = 0xde8; //STExtraVehicleBase* CurrentVehicle;

	//Class: STExtraBaseCharacter
	uintptr_t bIsWeaponFiring = 0x1608; //bool bIsWeaponFiring;
    uintptr_t NearDeathBreath = 0x1940; //float NearDeathBreath;
	uintptr_t ParachuteComponent = 0x6a00; //CharacterParachuteComponent* ParachuteComponent;
    uintptr_t NearDeatchComponent = 0x1920; //STCharacterNearDeathComp* NearDeatchComponent;
	uintptr_t ThirdPersonCameraComponent = 0x1a90; //CameraComponent* ThirdPersonCameraComponent;
	uintptr_t STCharacterMovement = 0x1bc0; //STCharacterMovementComponent* STCharacterMovement;
	uintptr_t WeaponManagerComponent = 0x22b8; //CharacterWeaponManagerComponent* WeaponManagerComponent;
	uintptr_t SwitchWeaponSpeedScale = 0x28b0; //float SwitchWeaponSpeedScale;
	
	//Class: UAEPlayerController
	uintptr_t LocalUID = 0x908; //uint64 UID;
	uintptr_t LocalTeamID = 0x928; //int TeamID;//[Offset: 0x868, Size: 0x4]

    //Class: STCharacterNearDeathComp
    uintptr_t BreathMax = 0x16c; //float BreathMax;
    
	//Class: STExtraPlayerCharacter
	uintptr_t STPlayerController = 0x3ec8; //STExtraPlayerController* STPlayerController;

	//Class: STExtraShootWeapon
	uintptr_t CurBulletNumInClip = 0xea0; //int CurBulletNumInClip;
	uintptr_t CurMaxBulletNumInOneClip = 0xec0; //int CurMaxBulletNumInOneClip;
	uintptr_t ShootWeaponEntityComp = 0xff8; //ShootWeaponEntity* ShootWeaponEntityComp;
	
	//Class: WeaponManagerComponent
	uintptr_t CurrWeapon = 0x500; //STExtraWeapon* CurrentWeaponReplicated;

	//Class: WeaponEntity
	uintptr_t UploadInterval = 0x178; //int Weaponid;

    //Class: ShootWeaponEntity
    uintptr_t BulletFireSpeed = 0x4f8; //float BulletFireSpeed;
	uintptr_t ShootInterval = 0x530; //float ShootInterval;
	uintptr_t AutoAimingConfig = 0x990; 
uintptr_t AccessoriesVRecoilFactor = 0xb18; 
uintptr_t AccessoriesHRecoilFactor = 0xb1c; 
uintptr_t AccessoriesRecoveryFactor = 0xb20; 
uintptr_t GameDeviationFactor = 0xb90; 
uintptr_t RecoilKickADS = 0xc48; 
uintptr_t ExtraHitPerformScale = 0xc4c; 
uintptr_t AnimationKick = 0xc64; 

	//Class: CharacterParachuteComponent
	uintptr_t CurrentFallSpeed = 0x1cc; //float CurrentFallSpeed;
    
    //Class: PickUpListWrapperActor
    uintptr_t PickUpDataList = 0x8a0; //PickUpItemData[] PickUpDataList;
    uintptr_t PickUpDataListCount = 0x8a0 + 0x10; //PickUpItemData[] PickUpDataList + 0x8;

    //Class: STExtraVehicleBase
    uintptr_t VehicleCommon = 0x6e0; //VehicleCommonComponent* VehicleCommon;

	//Class: VehicleCommonComponent
	uintptr_t VHealthMax = 0x2c0; //float HPMax;
	uintptr_t VHealth = 0x2c4; //float HP;
	uintptr_t VFuelMax = 0x334; //float FuelMax;
	uintptr_t VFuel = 0x338; //float Fuel;
	
	//Dalton - @D1_VIP
}


#endif
