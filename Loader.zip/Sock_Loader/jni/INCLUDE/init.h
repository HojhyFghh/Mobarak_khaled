#ifndef INIT_H
#define INIT_H

char version[69]="com.tencent.ig";
float healthbuff[2], health, aimRadius = 200;
int firing = 0, aimBy = 1, aimFor = 1;
int wideView;
bool isWideView = false;
bool isPremium = false;
bool aimbot = true;
bool aimKnoced = false;
bool isLessRecoil = false;
bool isZeroRecoil = false;
bool isNoShake = false;
bool isSmallCrosshair = false;
bool isFastParachute = false;
bool isInstantHit = false;
bool isHitX = false;
bool isMetro = false;
bool isRadar = false;
//bool bGudFrontView = false;
//bool isFastShootInterval = true;
//bool isFastSwitchWeapon = true;
//int isIpadView = -1;
//bool isSpeedKnock = true;
//bool isAimbot = false;
//bool isIpadViewOn = false;

#endif
